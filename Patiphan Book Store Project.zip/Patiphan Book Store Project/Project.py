import sqlite3
from tkinter import *
from tkinter import messagebox
from tkinter import ttk
from tkinter import messagebox as mb
import json
import random

def connection() :
    global conn,cursor
    conn = sqlite3.connect("database\data.db")
    cursor = conn.cursor()

def mainwindow() :
    root = Tk()
    w = 1000
    h = 600
    x = root.winfo_screenwidth()/2 - w/2
    y = root.winfo_screenheight()/2 - h/2
    root.geometry("%dx%d+%d+%d"%(w,h,x,y))
    root.config(bg='#3E54AC')
    root.title("Patiphan Book store")
    root.option_add('*font',"Garamond, 14")
    root.rowconfigure((0,3),weight=1)
    root.rowconfigure((1,2),weight=10)
    root.columnconfigure((0,3),weight=1)
    root.columnconfigure((1,2),weight=10)
    return root

def loginlayout() :
    global userentry,pwdentry
    loginframe.rowconfigure((0,1,2,3),weight=1)
    loginframe.columnconfigure((0,1),weight=1)
    loginframe.grid(row=1,column=1,columnspan=2,rowspan=2,sticky='news')
    Label(loginframe,text="        USER  LOGIN",font="Garamond 20 bold",bg='#ACDCEE',fg='black').place(x=570,y=125)
    Label(loginframe,text="Username  :",bg='#ACDCEE',fg='black',font="Garamond 20 bold").place(x=550,y=220)
    Label(loginframe,text="Password  :",bg='#ACDCEE',fg='black',font="Garamond 20 bold").place(x=560,y=295)
    userentry = Entry(loginframe,bg='#e4fbff',width=15)
    userentry.place(x=720,y=220)
    pwdentry = Entry(loginframe,bg='#e4fbff',width=15,show='*')
    pwdentry.place(x=720,y=295)
    Button(loginframe,text="Login",width=6,bg="#3E54AC",font="Garamond 20 bold",fg='white',command=lambda:loginclick(userentry.get(),pwdentry.get())).grid(row=3,column=1,pady=50,sticky='e',padx=260)
    Button(loginframe,text="Sign in",width=6,bg="#3E54AC",font="Garamond 20 bold",fg='white',command=regislayout).grid(row=3,column=1,pady=50,sticky='e',padx=110)
    Label(loginframe,image=logo,borderwidth=0, relief="solid").place(x=20,y=100)

def loginclick(user,pwd) :
    global result
    if user == "" or pwd == "" :
        messagebox.showwarning("Admin : ","Please enter a username / password")
        userentry.focus_force()
    else :
        sql = "select * from userinfo where user_name=?;"
        cursor.execute(sql,[user])
        result = cursor.fetchone()
        if result :
            sql = "select * from userinfo where user_name=? and pass_word=?;"
            cursor.execute(sql,[user,pwd])
            result = cursor.fetchone()
            if result :
                messagebox.showinfo("Admin : ","Login Successfully.")
                welcomepage(result)
            else :
                messagebox.showwarning("Admin : ","Incorrect Password \nPlease try again")
                pwdentry.selection_range(0,END)
                pwdentry.focus_force()
        else :
            messagebox.showwarning("Admin : ","The username not found \n Please sign in your account")
            userentry.selection_range(0,END)
            userentry.focus_force()

def regislayout() :
    global fullname,lastname,newuser,newpwd,cfpwd
    root.title("Patiphan Book store")
    root.config(bg='#ACDCEE')
    regisframe.rowconfigure((0,1,2,3,4,5,6),weight=1)
    regisframe.columnconfigure((0,1),weight=1)
    Label(regisframe,text="    ' Create Your Book Store Account '",font="Helvetica 24 bold",fg='#e4fbff',image=img1,compound=LEFT,bg='#398AB9').grid(row=0,column=0,columnspan=2,sticky='news')
    Label(regisframe,text='Firstname  : ',font="Helvetica 16 bold",bg='#ACDCEE',fg='black').grid(row=1,column=0,sticky='e',padx=10)
    fullname = Entry(regisframe,width=20,bg='#d3e0ea')
    fullname.grid(row=1,column=1,sticky='w',padx=10)
    Label(regisframe,text='Lastname  : ',font="Helvetica 16 bold",bg='#ACDCEE',fg='black').grid(row=2,column=0,sticky='e',padx=10)
    lastname = Entry(regisframe,width=20,bg='#d3e0ea')
    lastname.grid(row=2,column=1,sticky='w',padx=10)
    Label(regisframe,text="Username  : ",font="Helvetica 16 bold",bg='#ACDCEE',fg='black').grid(row=3,column=0,sticky='e',padx=10)
    newuser = Entry(regisframe,width=20,bg='#d3e0ea')
    newuser.grid(row=3,column=1,sticky='w',padx=10)
    Label(regisframe,text="Password  : ",font="Helvetica 16 bold",bg='#ACDCEE',fg='black').grid(row=4,column=0,sticky='e',padx=10)
    newpwd = Entry(regisframe,width=20,bg='#a1cae2',show='*')
    newpwd.grid(row=4,column=1,sticky='w',padx=10)
    Label(regisframe,text="Confirm your Password  : ",font="Helvetica 16 bold",bg='#ACDCEE',fg='black').grid(row=5,column=0,sticky='e',padx=10)
    cfpwd = Entry(regisframe,width=20,bg='#a1cae2',show='*')
    cfpwd.grid(row=5,column=1,sticky='w',padx=10)
    regisaction = Button(regisframe,text="Register Confirm",font="Helvetica 16 bold",command=registration)
    regisaction.grid(row=6,column=1,ipady=5,ipadx=5,pady=5,sticky='w',padx=30)
    fullname.focus_force()
    loginbtn = Button(regisframe,text="Back to Login",font="Helvetica 16 bold",command=logoutclick2)
    loginbtn.grid(row=6,column=0,ipady=5,ipadx=5,pady=5,sticky='e',padx=10)
    regisframe.grid(row=1,column=1,columnspan=2,rowspan=2,sticky='news')

def registration() :
    #print("Hello from registration")
    if fullname.get() == "" :
        messagebox.showwarning("Admin: ","Please enter a firstname")
        fullname.focus_force()
    elif lastname.get() == "" :
        messagebox.showwarning("Admin : ","Please enter a lastname")
        lastname.focus_force
    elif newuser.get() == "" :
        messagebox.showwarning("Admin : ","Please enter a username")
        newuser.focus_force
    elif newpwd.get() == "" :
        messagebox.showwarning("Admin : ","Please enter a password")
        newpwd.focus_force
    elif cfpwd.get() == "" :
        messagebox.showwarning("Admin : ","Please enter a confirm password")
        cfpwd.focus_force
    else : # check a username is already exist???
        sql = "select * from userinfo where user_name=?;"
        #execute sql query
        cursor.execute(sql,[newuser.get()])
        result = cursor.fetchone()#fetch a result
        if result :
            messagebox.showerror("Admin:","The username is already exists\n Try again")
            newuser.selection_range(0,END)
            newuser.focus_force
        else :
            if newpwd.get() == cfpwd.get() : #verify a new pwd and confirm pwd are equal
                sql = "insert into userinfo values (?,?,?,?) ;"
                #execute sql query 
                cursor.execute(sql,[newuser.get(),newpwd.get(),fullname.get(),lastname.get()])
                conn.commit()
                retrivedata()
                messagebox.showinfo("Admin:","Registration Successfully")
                resetdata()            
            else :  #verify a new pwd and confirm pwd are not equal
                messagebox.showwarning("Admin: ","Incorrect a confirm password\n Try again")
                cfpwd.selection_range(0,END)
                cfpwd.focus_force()

def retrivedata() :
    sql = "select * from userinfo"
    cursor.execute(sql)
    results = cursor.fetchall()
    print("Total row = ",len(results))
    for i,data in enumerate(results) :
        print("Row#",i+1,data)

def resetdata() :
    fullname.delete(0,END)
    lastname.delete(0,END)
    newuser.delete(0,END)
    newpwd.delete(0,END)
    cfpwd.delete(0,END)

def welcomepage(results) :
    loginframe.grid_forget()
    welcomeframe.grid_rowconfigure((0,1,2,3,4,5),weight=1)
    welcomeframe.grid_columnconfigure((0,1,2,3,4,5,6,7),weight=1)
    welcomeframe.grid(row=1,column=1,columnspan=2,rowspan=2,sticky='news')
    Label(welcomeframe,image=mostlogo,borderwidth=0,relief="solid").grid(row=0,column=1)
    Button(welcomeframe,text="Quiz ",font="Garamond 20 bold",image=c4,compound=LEFT,bg='white',command=quizpage).grid(row=0,column=2)
    Button(welcomeframe,text="Store ",font="Garamond 20 bold",image=c3,compound=LEFT,bg='white',command=coursepage).grid(row=0,column=3)
    Button(welcomeframe,text="Cart ",font="Garamond 20 bold",image=c1,compound=LEFT,bg='white',command=cartpage).grid(row=0,column=4)
    Button(welcomeframe,text="Log Out ",font="Garamond 20 bold",image=c2,compound=LEFT,bg='white',command=logoutclick).grid(row=0,column=5)
    Button(welcomeframe,text="Store",borderwidth=0,relief="solid",font="Garamond 20 bold",image=cutton,bg='white',command=coursepage).grid(row=2,column=5)
    Button(welcomeframe,text="Quiz",borderwidth=0,relief="solid",font="Garamond 20 bold",image=cutton2,bg='white',command=quizpage).grid(row=4,column=1)
    Label(welcomeframe,image=detail,borderwidth=0,relief="solid").place(x=40,y=135)
    Label(welcomeframe,image=detail2,borderwidth=0,relief="solid").place(x=240,y=345)

def quizpage():
    cartframe.grid_forget()
    quizcomframe.grid_forget()
    quizengframe.grid_forget()
    quizmathframe.grid_forget()
    quizframe.grid_rowconfigure((0,1,2,3,4,5,6,7,8,9),weight=1)
    quizframe.grid_columnconfigure((0,1,2,3,4,5),weight=1)
    quizframe.grid(row=0,column=0,columnspan=4,rowspan=4,sticky='news')


    Button(quizframe,text="Back",bg='white',command=homepage).grid(row=8,column=0)
    Button(quizframe,text="Back",bg='white',image=qc,command=quizcom).grid(row=3,column=2)
    Button(quizframe,text="Back",bg='white',image=qc2,command=quizeng).grid(row=5,column=2)
    Button(quizframe,text="Back",bg='white',image=qc3,command=quizmath).grid(row=7,column=2)

    Label(quizframe,text="  :",bg='#FACCB0',font="Garamond 26 bold")
    Label(quizframe,text="  :",bg='#FACCB0',font="Garamond 26 bold")
    Label(quizframe,text="  :",bg='#FACCB0',font="Garamond 26 bold")

    Label(quizframe,image=l1,borderwidth=0,relief="solid").grid(row=3,column=3)
    Label(quizframe,image=l2,borderwidth=0,relief="solid").grid(row=5,column=3)
    Label(quizframe,image=l3,borderwidth=0,relief="solid").grid(row=7,column=3)

    Label(quizframe,image=l1,borderwidth=0,relief="solid").grid(row=3,column=1)
    Label(quizframe,image=l2,borderwidth=0,relief="solid").grid(row=5,column=1)
    Label(quizframe,image=l3,borderwidth=0,relief="solid").grid(row=7,column=1)

def quizcom():
    quizframe.grid_forget()
    quizcomframe.grid_rowconfigure((0,1,2,3,4,5,6,7,8,9),weight=1)
    quizcomframe.grid_columnconfigure((0,1,2,3,4,5),weight=1)
    quizcomframe.grid(row=1,column=1,columnspan=2,rowspan=2,sticky='news')
    with open('quiz.json') as f:
        obj = json.load(f)
    q = (obj['ques'])
    options = (obj['options'])
    a = (obj['ans'])

    class Quiz:
        def __init__(self):
            self.qn = 0
            self.ques = self.question(self.qn)
            self.opt_selected = IntVar()
            self.opts = self.radiobtns()
            self.display_options(self.qn)
            self.buttons()
            self.correct = 0

        def question(self, qn):
            t = Label(quizcomframe, text="Basic Programming Quiz ?", width=50, bg="#A6D0DD", fg="black", font=("times", 25, "bold"))
            t.place(x=1, y=20)
            qn = Label(quizcomframe, text=q[qn], width=60, bg="#A6D0DD", font=("times", 16, "bold"), anchor="w")
            qn.place(x=70, y=100)
            return qn

        def radiobtns(self):
            val = 0
            b = []
            yp = 150
            while val < 4:
                btn = Radiobutton(quizcomframe, text=" ", variable=self.opt_selected,bg="#A6D0DD", value=val + 1, font=("times", 14))
                b.append(btn)
                btn.place(x=100, y=yp)
                val += 1
                yp += 45
            return b

        def display_options(self, qn):
            val = 0
            self.opt_selected.set(0)
            self.ques['text'] = q[qn]
            for op in options[qn]:
                self.opts[val]['text'] = op
                val += 1

        def buttons(self):
            nbutton = Button(quizcomframe, text="Next",command=self.nextbtn, width=10,bg="#AFD3E2",fg="black",font=("times",16,"bold"))
            nbutton.place(x=330,y=440)
            quitbutton = Button(quizcomframe, text="Quit",command=quizpage,width=10,bg="#3282B8",fg="black", font=("times",16,"bold"))
            quitbutton.place(x=510,y=440)

        def checkans(self, qn):
            if self.opt_selected.get() == a[qn]:
                return True
            
        def nextbtn(self):
            if self.checkans(self.qn):
                self.correct += 1
            self.qn += 1
            if self.qn == len(q):
                self.display_result()
            else:
                self.display_options(self.qn)       
            

        def display_result(self):
            score = int(self.correct / len(q) * 100)
            result = "Score: " + str(score) + "%"
            wc = len(q) - self.correct
            correct = "No. of correct answers: " + str(self.correct)
            wrong = "No. of wrong answers: " + str(wc)
            mb.showinfo("Result", "\n".join([result, correct, wrong]))
        
    quiz=Quiz()

def quizeng():
    quizframe.grid_forget()
    quizengframe.grid_rowconfigure((0,1,2,3,4,5,6,7,8,9),weight=1)
    quizengframe.grid_columnconfigure((0,1,2,3,4,5),weight=1)
    quizengframe.grid(row=1,column=1,columnspan=2,rowspan=2,sticky='news')
    with open('quiz3.json') as f:
        obj = json.load(f)
    q = (obj['ques'])
    options = (obj['options'])
    a = (obj['ans'])

    class Quiz:
        def __init__(self):
            self.qn = 0
            self.ques = self.question(self.qn)
            self.opt_selected = IntVar()
            self.opts = self.radiobtns()
            self.display_options(self.qn)
            self.buttons()
            self.correct = 0

        def question(self, qn):
            t = Label(quizengframe, text="Basic English Quiz ?", width=50, bg="#F7C8E0", fg="black", font=("times", 25, "bold"))
            t.place(x=1, y=20)
            qn = Label(quizengframe, text=q[qn], width=60, bg="#F7C8E0",  font=("times", 16, "bold"), anchor="w")
            qn.place(x=70, y=100)
            return qn

        def radiobtns(self):
            val = 0
            b = []
            yp = 150
            while val < 4:
                btn = Radiobutton(quizengframe, text=" ", bg="#F7C8E0",variable=self.opt_selected, value=val + 1, font=("times", 14))
                b.append(btn)
                btn.place(x=100, y=yp)
                val += 1
                yp += 45
            return b

        def display_options(self, qn):
            val = 0
            self.opt_selected.set(0)
            self.ques['text'] = q[qn]
            for op in options[qn]:
                self.opts[val]['text'] = op
                val += 1

        def buttons(self):
            nbutton = Button(quizengframe, text="Next",command=self.nextbtn, width=10,bg="#F7C8E0",fg="black",font=("times",16,"bold"))
            nbutton.place(x=330,y=440)
            quitbutton = Button(quizengframe, text="Quit",command=quizpage,width=10,bg="#D09CFA",fg="black", font=("times",16,"bold"))
            quitbutton.place(x=510,y=440)

        def checkans(self, qn):
            if self.opt_selected.get() == a[qn]:
                return True
            
        def nextbtn(self):
            if self.checkans(self.qn):
                self.correct += 1
            self.qn += 1
            if self.qn == len(q):
                self.display_result()
            else:
                self.display_options(self.qn)       
            

        def display_result(self):
            score = int(self.correct / len(q) * 100)
            result = "Score: " + str(score) + "%"
            wc = len(q) - self.correct
            correct = "No. of correct answers: " + str(self.correct)
            wrong = "No. of wrong answers: " + str(wc)
            mb.showinfo("Result", "\n".join([result, correct, wrong]))
        
    quiz=Quiz()

def quizmath():
    quizframe.grid_forget()
    quizmathframe.grid_rowconfigure((0,1,2,3,4,5,6,7,8,9),weight=1)
    quizmathframe.grid_columnconfigure((0,1,2,3,4,5),weight=1)
    quizmathframe.grid(row=1,column=1,columnspan=2,rowspan=2,sticky='news')
    with open('quiz2.json') as f:
        obj = json.load(f)
    q = (obj['ques'])
    options = (obj['options'])
    a = (obj['ans'])

    class Quiz:
        def __init__(self):
            self.qn = 0
            self.ques = self.question(self.qn)
            self.opt_selected = IntVar()
            self.opts = self.radiobtns()
            self.display_options(self.qn)
            self.buttons()
            self.correct = 0

        def question(self, qn):
            t = Label(quizmathframe, text="Basic Mathimatic Quiz ?", width=50, bg="#C7F2A4", fg="Black", font=("times", 25, "bold"))
            t.place(x=1, y=20)
            qn = Label(quizmathframe, text=q[qn],  bg="#C7F2A4",width=60, font=("times", 16, "bold"), anchor="w")
            qn.place(x=70, y=100)
            return qn

        def radiobtns(self):
            val = 0
            b = []
            yp = 150
            while val < 4:
                btn = Radiobutton(quizmathframe, text=" ", bg="#C7F2A4", variable=self.opt_selected, value=val + 1, font=("times", 14))
                b.append(btn)
                btn.place(x=100, y=yp)
                val += 1
                yp += 45
            return b

        def display_options(self, qn):
            val = 0
            self.opt_selected.set(0)
            self.ques['text'] = q[qn]
            for op in options[qn]:
                self.opts[val]['text'] = op
                val += 1

        def buttons(self):
            nbutton = Button(quizmathframe, text="Next",command=self.nextbtn, width=10,bg="#C7F2A4",fg="black",font=("times",16,"bold"))
            nbutton.place(x=330,y=440)
            quitbutton = Button(quizmathframe, text="Quit",command=quizpage,width=10,bg="#82CD47",fg="black", font=("times",16,"bold"))
            quitbutton.place(x=510,y=440)

        def checkans(self, qn):
            if self.opt_selected.get() == a[qn]:
                return True
            
        def nextbtn(self):
            if self.checkans(self.qn):
                self.correct += 1
            self.qn += 1
            if self.qn == len(q):
                self.display_result()
            else:
                self.display_options(self.qn)       
            

        def display_result(self):
            score = int(self.correct / len(q) * 100)
            result = "Score: " + str(score) + "%"
            wc = len(q) - self.correct
            correct = "No. of correct answers: " + str(self.correct)
            wrong = "No. of wrong answers: " + str(wc)
            mb.showinfo("Result", "\n".join([result, correct, wrong]))
        
    quiz=Quiz()

def homepage() :
    quizcomframe.grid_forget()
    quizengframe.grid_forget()
    quizmathframe.grid_forget()
    courseframe.grid_forget()
    courseframe2.grid_forget()
    courseframe3.grid_forget()
    courseframe4.grid_forget()
    cartframe.grid_forget()
    quizframe.grid_forget()
    welcomepage(result)

def coursepage() :
    cartframe.update()
    courseframe2.grid_forget()
    courseframe3.grid_forget()
    courseframe4.grid_forget()
    welcomeframe.grid_forget()
    cartframe.grid_forget()
    courseframe.grid_rowconfigure((0,1,2,3,4,5,6,7,8,9,10,11,12,13,14),weight=1)
    courseframe.grid_columnconfigure((0,1,2,3,4,5),weight=1)
    courseframe.grid(row=0,column=0,columnspan=4,rowspan=4,sticky='news')

    Label(courseframe,image=eng1).grid(row=4,column=1)
    Label(courseframe,image=com1).grid(row=4,column=2)
    Label(courseframe,image=math1).grid(row=4,column=3)
    Label(courseframe,image=eng2).grid(row=4,column=4)

    Label(courseframe,text=" 250 Bath  :",padx=30,bg='#C7F2A4').grid(row=5,column=1)
    Label(courseframe,text=" 199 Bath  :",padx=30,bg='#C7F2A4').grid(row=5,column=2)
    Label(courseframe,text=" 450 Bath  :",padx=30,bg='#C7F2A4').grid(row=5,column=3)
    Label(courseframe,text=" 399 Bath  :",padx=30,bg='#C7F2A4').grid(row=5,column=4)

    Spinbox(courseframe,from_=0,to=100,width=3,justify="center",textvariable=spy1,command=userclick).grid(row=5,column=1,sticky='e')
    Spinbox(courseframe,from_=0,to=100,width=3,justify="center",textvariable=spy2,command=userclick).grid(row=5,column=2,sticky='e')
    Spinbox(courseframe,from_=0,to=100,width=3,justify="center",textvariable=spy3,command=userclick).grid(row=5,column=3,sticky='e')
    Spinbox(courseframe,from_=0,to=100,width=3,justify="center",textvariable=spy4,command=userclick).grid(row=5,column=4,sticky='e')

    Label(courseframe,image=com2).grid(row=9,column=1)
    Label(courseframe,image=math2).grid(row=9,column=2)
    Label(courseframe,image=eng3).grid(row=9,column=3)
    Label(courseframe,image=math3).grid(row=9,column=4)

    Label(courseframe,text=" 299 Bath  :",padx=30,bg='#C7F2A4').grid(row=10,column=1)
    Label(courseframe,text=" 250 Bath  :",padx=30,bg='#C7F2A4').grid(row=10,column=2)
    Label(courseframe,text=" 199 Bath  :",padx=30,bg='#C7F2A4').grid(row=10,column=3)
    Label(courseframe,text=" 159 Bath  :",padx=30,bg='#C7F2A4').grid(row=10,column=4)

    Spinbox(courseframe,from_=0,to=100,width=3,justify="center",textvariable=spy5,command=userclick).grid(row=10,column=1,sticky='e')
    Spinbox(courseframe,from_=0,to=100,width=3,justify="center",textvariable=spy6,command=userclick).grid(row=10,column=2,sticky='e')
    Spinbox(courseframe,from_=0,to=100,width=3,justify="center",textvariable=spy7,command=userclick).grid(row=10,column=3,sticky='e')
    Spinbox(courseframe,from_=0,to=100,width=3,justify="center",textvariable=spy8,command=userclick).grid(row=10,column=4,sticky='e')

    Button(courseframe,text="|",bg='white').grid(row=13,column=2,ipadx=20)
    Button(courseframe,text=">",bg='white',command=coursepage2).grid(row=13,column=3,ipadx=20)
    Button(courseframe,text="Back",bg='white',command=homepage).grid(row=13,column=0)
    Button(courseframe,text="Go to Cart",bg='white',command=cartpage).grid(row=13,column=5)

def coursepage2():
    courseframe3.grid_forget()
    courseframe.grid_forget()
    welcomeframe.grid_forget()
    cartframe.grid_forget()
    courseframe2.grid_rowconfigure((0,1,2,3,4,5,6,7,8,9,10,11,12,13,14),weight=1)
    courseframe2.grid_columnconfigure((0,1,2,3,4,5),weight=1)
    courseframe2.grid(row=0,column=0,columnspan=4,rowspan=4,sticky='news')

    Label(courseframe2,image=com3).grid(row=4,column=1)
    Label(courseframe2,image=math4).grid(row=4,column=2)
    Label(courseframe2,image=eng4).grid(row=4,column=3)
    Label(courseframe2,image=com4).grid(row=4,column=4)

    Label(courseframe2,text=" 179 Bath  :",padx=30,bg='#C7F2A4').grid(row=5,column=1)
    Label(courseframe2,text=" 299 Bath  :",padx=30,bg='#C7F2A4').grid(row=5,column=2)
    Label(courseframe2,text=" 450 Bath  :",padx=30,bg='#C7F2A4').grid(row=5,column=3)
    Label(courseframe2,text=" 259 Bath  :",padx=30,bg='#C7F2A4').grid(row=5,column=4)

    Spinbox(courseframe2,from_=0,to=100,width=3,justify="center",textvariable=spy9,command=userclick).grid(row=5,column=1,sticky='e')
    Spinbox(courseframe2,from_=0,to=100,width=3,justify="center",textvariable=spy10,command=userclick).grid(row=5,column=2,sticky='e')
    Spinbox(courseframe2,from_=0,to=100,width=3,justify="center",textvariable=spy11,command=userclick).grid(row=5,column=3,sticky='e')
    Spinbox(courseframe2,from_=0,to=100,width=3,justify="center",textvariable=spy12,command=userclick).grid(row=5,column=4,sticky='e')

    Label(courseframe2,image=eng5).grid(row=9,column=1)
    Label(courseframe2,image=math5).grid(row=9,column=2)
    Label(courseframe2,image=com5).grid(row=9,column=3)
    Label(courseframe2,image=eng6).grid(row=9,column=4)

    Label(courseframe2,text=" 399 Bath  :",padx=30,bg='#C7F2A4').grid(row=10,column=1)
    Label(courseframe2,text=" 150 Bath  :",padx=30,bg='#C7F2A4').grid(row=10,column=2)
    Label(courseframe2,text=" 159 Bath  :",padx=30,bg='#C7F2A4').grid(row=10,column=3)
    Label(courseframe2,text=" 199 Bath  :",padx=30,bg='#C7F2A4').grid(row=10,column=4)

    Spinbox(courseframe2,from_=0,to=100,width=3,justify="center",textvariable=spy13,command=userclick).grid(row=10,column=1,sticky='e')
    Spinbox(courseframe2,from_=0,to=100,width=3,justify="center",textvariable=spy14,command=userclick).grid(row=10,column=2,sticky='e')
    Spinbox(courseframe2,from_=0,to=100,width=3,justify="center",textvariable=spy15,command=userclick).grid(row=10,column=3,sticky='e')
    Spinbox(courseframe2,from_=0,to=100,width=3,justify="center",textvariable=spy16,command=userclick).grid(row=10,column=4,sticky='e')

    Button(courseframe2,text="<",bg='white',command=coursepage).grid(row=13,column=2,ipadx=20)
    Button(courseframe2,text=">",bg='white',command=coursepage3).grid(row=13,column=3,ipadx=20)
    Button(courseframe2,text="Back",bg='white',command=homepage).grid(row=13,column=0)
    Button(courseframe2,text="Go to Cart",bg='white',command=cartpage).grid(row=13,column=5)

def coursepage3():
    courseframe4.grid_forget()
    courseframe.grid_forget()
    welcomeframe.grid_forget()
    cartframe.grid_forget()
    courseframe3.grid_rowconfigure((0,1,2,3,4,5,6,7,8,9,10,11,12,13,14),weight=1)
    courseframe3.grid_columnconfigure((0,1,2,3,4,5),weight=1)
    courseframe3.grid(row=0,column=0,columnspan=4,rowspan=4,sticky='news')

    Label(courseframe3,image=math6).grid(row=4,column=1)
    Label(courseframe3,image=com6).grid(row=4,column=2)
    Label(courseframe3,image=eng7).grid(row=4,column=3)
    Label(courseframe3,image=math7).grid(row=4,column=4)

    Label(courseframe3,text=" 499 Bath  :",padx=30,bg='#C7F2A4').grid(row=5,column=1)
    Label(courseframe3,text=" 259 Bath  :",padx=30,bg='#C7F2A4').grid(row=5,column=2)
    Label(courseframe3,text=" 329 Bath  :",padx=30,bg='#C7F2A4').grid(row=5,column=3)
    Label(courseframe3,text=" 179 Bath  :",padx=30,bg='#C7F2A4').grid(row=5,column=4)

    Spinbox(courseframe3,from_=0,to=100,width=3,justify="center",textvariable=spy17,command=userclick).grid(row=5,column=1,sticky='e')
    Spinbox(courseframe3,from_=0,to=100,width=3,justify="center",textvariable=spy18,command=userclick).grid(row=5,column=2,sticky='e')
    Spinbox(courseframe3,from_=0,to=100,width=3,justify="center",textvariable=spy19,command=userclick).grid(row=5,column=3,sticky='e')
    Spinbox(courseframe3,from_=0,to=100,width=3,justify="center",textvariable=spy20,command=userclick).grid(row=5,column=4,sticky='e')

    Label(courseframe3,image=com7).grid(row=9,column=1)
    Label(courseframe3,image=eng8).grid(row=9,column=2)
    Label(courseframe3,image=math8).grid(row=9,column=3)
    Label(courseframe3,image=com8).grid(row=9,column=4)

    Label(courseframe3,text=" 199 Bath  :",padx=30,bg='#C7F2A4').grid(row=10,column=1)
    Label(courseframe3,text=" 350 Bath  :",padx=30,bg='#C7F2A4').grid(row=10,column=2)
    Label(courseframe3,text=" 299 Bath  :",padx=30,bg='#C7F2A4').grid(row=10,column=3)
    Label(courseframe3,text=" 450 Bath  :",padx=30,bg='#C7F2A4').grid(row=10,column=4)

    Spinbox(courseframe3,from_=0,to=100,width=3,justify="center",textvariable=spy21,command=userclick).grid(row=10,column=1,sticky='e')
    Spinbox(courseframe3,from_=0,to=100,width=3,justify="center",textvariable=spy22,command=userclick).grid(row=10,column=2,sticky='e')
    Spinbox(courseframe3,from_=0,to=100,width=3,justify="center",textvariable=spy23,command=userclick).grid(row=10,column=3,sticky='e')
    Spinbox(courseframe3,from_=0,to=100,width=3,justify="center",textvariable=spy24,command=userclick).grid(row=10,column=4,sticky='e')

    Button(courseframe3,text="<",bg='white',command=coursepage2).grid(row=13,column=2,ipadx=20)
    Button(courseframe3,text=">",bg='white',command=coursepage4).grid(row=13,column=3,ipadx=20)
    Button(courseframe3,text="Back",bg='white',command=homepage).grid(row=13,column=0)
    Button(courseframe3,text="Go to Cart",bg='white',command=cartpage).grid(row=13,column=5)

def coursepage4():
    courseframe.grid_forget()
    welcomeframe.grid_forget()
    cartframe.grid_forget()
    courseframe4.grid_rowconfigure((0,1,2,3,4,5,6,7,8,9,10,11,12,13,14),weight=1)
    courseframe4.grid_columnconfigure((0,1,2,3,4,5),weight=1)
    courseframe4.grid(row=0,column=0,columnspan=4,rowspan=4,sticky='news')

    Label(courseframe4,image=eng9).grid(row=4,column=1)
    Label(courseframe4,image=math9).grid(row=4,column=2)
    Label(courseframe4,image=com9).grid(row=4,column=3)
    Label(courseframe4,image=eng10).grid(row=4,column=4)

    Label(courseframe4,text=" 129 Bath  :",padx=30,bg='#C7F2A4').grid(row=5,column=1)
    Label(courseframe4,text=" 399 Bath  :",padx=30,bg='#C7F2A4').grid(row=5,column=2)
    Label(courseframe4,text=" 250 Bath  :",padx=30,bg='#C7F2A4').grid(row=5,column=3)
    Label(courseframe4,text=" 429 Bath  :",padx=30,bg='#C7F2A4').grid(row=5,column=4)

    Spinbox(courseframe4,from_=0,to=100,width=3,justify="center",textvariable=spy25,command=userclick).grid(row=5,column=1,sticky='e')
    Spinbox(courseframe4,from_=0,to=100,width=3,justify="center",textvariable=spy26,command=userclick).grid(row=5,column=2,sticky='e')
    Spinbox(courseframe4,from_=0,to=100,width=3,justify="center",textvariable=spy27,command=userclick).grid(row=5,column=3,sticky='e')
    Spinbox(courseframe4,from_=0,to=100,width=3,justify="center",textvariable=spy28,command=userclick).grid(row=5,column=4,sticky='e')

    Label(courseframe4,image=math10).grid(row=9,column=1)
    Label(courseframe4,image=com10).grid(row=9,column=2)
    Label(courseframe4,image=math11).grid(row=9,column=3)
    Label(courseframe4,image=com11).grid(row=9,column=4)

    Label(courseframe4,text=" 329 Bath  :",padx=30,bg='#C7F2A4').grid(row=10,column=1)
    Label(courseframe4,text=" 170 Bath  :",padx=30,bg='#C7F2A4').grid(row=10,column=2)
    Label(courseframe4,text=" 359 Bath  :",padx=30,bg='#C7F2A4').grid(row=10,column=3)
    Label(courseframe4,text=" 199 Bath  :",padx=30,bg='#C7F2A4').grid(row=10,column=4)

    Spinbox(courseframe4,from_=0,to=100,width=3,justify="center",textvariable=spy29,command=userclick).grid(row=10,column=1,sticky='e')
    Spinbox(courseframe4,from_=0,to=100,width=3,justify="center",textvariable=spy30,command=userclick).grid(row=10,column=2,sticky='e')
    Spinbox(courseframe4,from_=0,to=100,width=3,justify="center",textvariable=spy31,command=userclick).grid(row=10,column=3,sticky='e')
    Spinbox(courseframe4,from_=0,to=100,width=3,justify="center",textvariable=spy32,command=userclick).grid(row=10,column=4,sticky='e')

    Button(courseframe4,text="<",bg='white',command=coursepage3).grid(row=13,column=2,ipadx=20)
    Button(courseframe4,text="|",bg='white').grid(row=13,column=3,ipadx=20)
    Button(courseframe4,text="Back",bg='white',command=homepage).grid(row=13,column=0)
    Button(courseframe4,text="Go to Cart",bg='white',command=cartpage).grid(row=13,column=5)

def userclick () :
    global total
    total = 0
    amt = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20]
    book1 = [0,250, 500, 750, 1000, 1250, 1500, 1750, 2000, 2250, 2500, 2750, 3000, 3250, 3500, 3750, 4000, 4250, 4500, 4750, 5000]
    book2 = [0,199, 398, 597, 796, 995, 1194, 1393, 1592, 1791, 1990, 2189, 2388, 2587, 2786, 2985, 3184, 3383, 3582, 3781, 3980]
    book3 = [0,450, 900, 1350, 1800, 2250, 2700, 3150, 3600, 4050, 4500, 4950, 5400, 5850, 6300, 6750, 7200, 7650, 8100, 8550, 9000,900,1350,1800]
    book4 = [0,399, 798, 1197, 1596, 1995, 2394, 2793, 3192, 3591, 3990, 4389, 4788, 5187, 5586, 5985, 6384, 6783, 7182, 7581, 7980]
    book5 = [0,299, 598, 897, 1196, 1495, 1794, 2093, 2392, 2691, 2990, 3289, 3588, 3887, 4186, 4485, 4784, 5083, 5382, 5681, 5980]
    book6 = [0,250, 500, 750, 1000, 1250, 1500, 1750, 2000, 2250, 2500, 2750, 3000, 3250, 3500, 3750, 4000, 4250, 4500, 4750, 5000]
    book7 = [0,199, 398, 597, 796, 995, 1194, 1393, 1592, 1791, 1990, 2189, 2388, 2587, 2786, 2985, 3184, 3383, 3582, 3781, 3980]
    book8 = [0,159, 318, 477, 636, 795, 954, 1113, 1272, 1431, 1590, 1749, 1908, 2067, 2226, 2385, 2544, 2703, 2862, 3021, 3180]
    book9 = [0,179, 358, 537, 716, 895, 1074, 1253, 1432, 1611, 1790, 1969, 2148, 2327, 2506, 2685, 2864, 3043, 3222, 3401, 3580]
    book10 = [0,299, 598, 897, 1196, 1495, 1794, 2093, 2392, 2691, 2990, 3289, 3588, 3887, 4186, 4485, 4784, 5083, 5382, 5681, 5980]
    book11 = [0,450, 900, 1350, 1800, 2250, 2700, 3150, 3600, 4050, 4500, 4950, 5400, 5850, 6300, 6750, 7200, 7650, 8100, 8550, 9000]
    book12 = [0,259, 518, 777, 1036, 1295, 1554, 1813, 2072, 2331, 2590, 2849, 3108, 3367, 3626, 3885, 4144, 4403, 4662, 4921, 5180]
    book13 = [0,399, 798, 1197, 1596, 1995, 2394, 2793, 3192, 3591, 3990, 4389, 4788, 5187, 5586, 5985, 6384, 6783, 7182, 7581, 7980]
    book14 = [0,150, 300, 450, 600, 750, 900, 1050, 1200, 1350, 1500, 1650, 1800, 1950, 2100, 2250, 2400, 2550, 2700, 2850, 3000]
    book15 = [0,159, 318, 477, 636, 795, 954, 1113, 1272, 1431, 1590, 1749, 1908, 2067, 2226, 2385, 2544, 2703, 2862, 3021, 3180]
    book16 = [0,199, 398, 597, 796, 995, 1194, 1393, 1592, 1791, 1990, 2189, 2388, 2587, 2786, 2985, 3184, 3383, 3582, 3781, 3980]
    book17 = [0,499, 998, 1497, 1996, 2495, 2994, 3493, 3992, 4491, 4990, 5489, 5988, 6487, 6986, 7485, 7984, 8483, 8982, 9481, 9980]
    book18 = [0,259, 518, 777, 1036, 1295, 1554, 1813, 2072, 2331, 2590, 2849, 3108, 3367, 3626, 3885, 4144, 4403, 4662, 4921, 5180]
    book19 = [0,329, 658, 987, 1316, 1645, 1974, 2303, 2632, 2961, 3290, 3619, 3948, 4277, 4606, 4935, 5264, 5593, 5922, 6251, 6580]
    book20 = [0,179, 358, 537, 716, 895, 1074, 1253, 1432, 1611, 1790, 1969, 2148, 2327, 2506, 2685, 2864, 3043, 3222, 3401, 3580]
    book21 = [0,199, 398, 597, 796, 995, 1194, 1393, 1592, 1791, 1990, 2189, 2388, 2587, 2786, 2985, 3184, 3383, 3582, 3781, 3980]
    book22 = [0,350, 700, 1050, 1400, 1750, 2100, 2450, 2800, 3150, 3500, 3850, 4200, 4550, 4900, 5250, 5600, 5950, 6300, 6650, 7000]
    book23 = [0,299, 598, 897, 1196, 1495, 1794, 2093, 2392, 2691, 2990, 3289, 3588, 3887, 4186, 4485, 4784, 5083, 5382, 5681, 5980]
    book24 = [0,450, 900, 1350, 1800, 2250, 2700, 3150, 3600, 4050, 4500, 4950, 5400, 5850, 6300, 6750, 7200, 7650, 8100, 8550, 9000]
    book25 = [0,129, 258, 387, 516, 645, 774, 903, 1032, 1161, 1290, 1419, 1548, 1677, 1806, 1935, 2064, 2193, 2322, 2451, 2580]
    book26 = [0,399, 798, 1197, 1596, 1995, 2394, 2793, 3192, 3591, 3990, 4389, 4788, 5187, 5586, 5985, 6384, 6783, 7182, 7581, 7980]
    book27 = [0,250, 500, 750, 1000, 1250, 1500, 1750, 2000, 2250, 2500, 2750, 3000, 3250, 3500, 3750, 4000, 4250, 4500, 4750, 5000]
    book28 = [0,429, 858, 1287, 1716, 2145, 2574, 3003, 3432, 3861, 4290, 4719, 5148, 5577, 6006, 6435, 6864, 7293, 7722, 8151, 8580]
    book29 = [0,329, 658, 987, 1316, 1645, 1974, 2303, 2632, 2961, 3290, 3619, 3948, 4277, 4606, 4935, 5264, 5593, 5922, 6251, 6580]
    book30 = [0,170, 340, 510, 680, 850, 1020, 1190, 1360, 1530, 1700, 1870, 2040, 2210, 2380, 2550, 2720, 2890, 3060, 3230, 3400]
    book31 = [0,359, 718, 1077, 1436, 1795, 2154, 2513, 2872, 3231, 3590, 3949, 4308, 4667, 5026, 5385, 5744, 6103, 6462, 6821, 7180]
    book32 = [0,199, 398, 597, 796, 995, 1194, 1393, 1592, 1791, 1990, 2189, 2388, 2587, 2786, 2985, 3184, 3383, 3582, 3781, 3980]
    for i in range(len(amt)) :
        if spy1.get() == i:
            total += book1[i]
    for i in range(len(amt)) :
        if spy2.get() == i:
            total +=  book2[i]
    for i in range(len(amt)) :
        if spy3.get() == i:
            total +=  book3[i]
    for i in range(len(amt)) :
        if spy4.get() == i:
            total +=  book4[i]
    for i in range(len(amt)) :
        if spy5.get() == i:
            total +=  book5[i]  
    for i in range(len(amt)) :
        if spy6.get() == i:
            total +=  book6[i]
    for i in range(len(amt)) :
        if spy7.get() == i:
            total +=  book7[i]
    for i in range(len(amt)) :
        if spy8.get() == i:
            total +=  book8[i]
    for i in range(len(amt)) :
        if spy9.get() == i:
            total +=  book9[i]
    for i in range(len(amt)) :
        if spy10.get() == i:
            total +=  book10[i]
    for i in range(len(amt)) :
        if spy11.get() == i:
            total +=  book11[i]
    for i in range(len(amt)) :
        if spy12.get() == i:
            total +=  book12[i]
    for i in range(len(amt)) :
        if spy13.get() == i:
            total +=  book13[i]
    for i in range(len(amt)) :
        if spy14.get() == i:
            total +=  book14[i]
    for i in range(len(amt)) :
        if spy15.get() == i:
            total +=  book15[i]
    for i in range(len(amt)) :
        if spy16.get() == i:
            total +=  book16[i]
    for i in range(len(amt)) :
        if spy17.get() == i:
            total +=  book17[i]
    for i in range(len(amt)) :
        if spy18.get() == i:
            total +=  book18[i]
    for i in range(len(amt)) :
        if spy19.get() == i:
            total +=  book19[i]
    for i in range(len(amt)) :
        if spy20.get() == i:
            total +=  book20[i]
    for i in range(len(amt)) :
        if spy21.get() == i:
            total +=  book21[i]
    for i in range(len(amt)) :
        if spy22.get() == i:
            total +=  book22[i]
    for i in range(len(amt)) :
        if spy23.get() == i:
            total +=  book23[i]
    for i in range(len(amt)) :
        if spy24.get() == i:
            total +=  book24[i]
    for i in range(len(amt)) :
        if spy25.get() == i:
            total +=  book25[i]
    for i in range(len(amt)) :
        if spy26.get() == i:
            total +=  book26[i]
    for i in range(len(amt)) :
        if spy27.get() == i:
            total +=  book27[i]
    for i in range(len(amt)) :
        if spy28.get() == i:
            total +=  book28[i]
    for i in range(len(amt)) :
        if spy29.get() == i:
            total +=  book29[i]
    for i in range(len(amt)) :
        if spy30.get() == i:
            total +=  book31[i]
    for i in range(len(amt)) :
        if spy31.get() == i:
            total +=  book31[i]
    for i in range(len(amt)) :
        if spy32.get() == i:
            total +=  book32[i]
    Label(cartframe,text="Total price is "+str(total)+" Bath",font=("Opens san",(17)),fg="#02273f",bg="#BDCDD6").place(x=650,y=450)

def click() :
    global total
    if spy.get() :
        total = total-(total*(0.1))
        Label(cartframe,text="Total price is "+str(total)+" Bath",font=("Opens san",(17)),fg="#02273f",bg="#BDCDD6").place(x=650,y=450)

def click2() :
    global total
    if spyt.get() :
        total = total+20
        Label(cartframe,text="Total price is "+str(total)+" Bath",font=("Opens san",(17)),fg="#02273f",bg="#BDCDD6").place(x=650,y=450)

def cartpage() :
    global y,e,a,p,pc,ph
    welcomeframe.grid_forget()
    courseframe.grid_forget()
    cartframe.grid_rowconfigure((0,1,2,3,4,5,7,8,9,10,),weight=1)
    cartframe.grid_columnconfigure((0,1,2,3,4,5,6),weight=1)
    cartframe.grid(row=0,column=0,columnspan=4,rowspan=4,sticky='news')


    Label(cartframe,image=mostlogo,borderwidth=0,relief="solid").grid(row=0,column=1)
    Button(cartframe,text="Home ",bg='white',image=c5,compound=LEFT,command=homepage).grid(row=0,column=2)
    Button(cartframe,text="Store ",bg='white',image=c3,compound=LEFT,command=coursepage).grid(row=0,column=3)
    Button(cartframe,text="Quiz ",bg='white',image=c4,compound=LEFT,command=quizpage).grid(row=0,column=4)
    Button(cartframe,text="Log Out ",bg='white',image=c2,compound=LEFT,command=logoutclick4).grid(row=0,column=5)

    Label(cartframe,text="        Shipping Address",font="Garamond 22 bold",bg='#ACDCEE').place(x=150,y=130)
    Label(cartframe,text="   Yourname     : ",bg='#ACDCEE').place(x=130,y=200)
    Label(cartframe,text="          Email     : ",bg='#ACDCEE').place(x=130,y=250)
    Label(cartframe,text="     Address     : ",bg='#ACDCEE').place(x=130,y=300)
    Label(cartframe,text="     Province     : ",bg='#ACDCEE').place(x=130,y=350)
    Label(cartframe,text="Postal code     : ",bg='#ACDCEE').place(x=130,y=400)
    Label(cartframe,text="         Phone     : ",bg='#ACDCEE').place(x=130,y=450)

    y = Entry(cartframe,width=20,bg='#a1cae2')
    y.place(x=290,y=200)
    e = Entry(cartframe,width=20,bg='#a1cae2')
    e.place(x=290,y=250)
    a = Entry(cartframe,width=20,bg='#a1cae2')
    a.place(x=290,y=300)
    p = Entry(cartframe,width=20,bg='#a1cae2')
    p.place(x=290,y=350)
    pc = Entry(cartframe,width=20,bg='#a1cae2')
    pc.place(x=290,y=400)
    ph = Entry(cartframe,width=20,bg='#a1cae2')
    ph.place(x=290,y=450)

    Checkbutton(cartframe,text="Online member\n(Discount 10 %)",variable=spy,command=click,bg="#a1cae2").place(x=140,y=515)
    Checkbutton(cartframe,text="Cash on delivery\n(Fee 20 Bath)",variable=spyt,command=click2,bg="#a1cae2").place(x=350,y=515)

    Label(cartframe,image=thank,borderwidth=0,relief="solid").place(x=530,y=110)
    Button(cartframe,text="Confirm Order ",bg='white',font="Garamond 22 bold",command=resetdata2).place(x=665,y=515)

def resetdata2() :
    y.delete(0,END)
    e.delete(0,END)
    a.delete(0,END)
    p.delete(0,END)
    pc.delete(0,END)
    ph.delete(0,END)
    messagebox.showinfo("Admin:","Order completed !\nThank you for using Patiphan book store.")

def logoutclick() :
    loginlayout()
    welcomeframe.grid_forget()

def logoutclick2() :
    loginlayout()
    regisframe.grid_forget()

def logoutclick3() :
    loginlayout()
    courseframe.grid_forget()
    welcomeframe.grid_forget()
    cartframe.grid_forget()

def logoutclick4() :
    loginlayout()
    courseframe.grid_forget()
    welcomeframe.grid_forget()
    cartframe.grid_forget()

connection()
root = mainwindow()
loginframe = Frame(root,bg="#ACDCEE")
welcomeframe = Frame(root,bg="#ACDCEE")
regisframe = Frame(root,bg='#ACDCEE')
quizframe = Frame(root,bg='#FACCB0')
quizcomframe = Frame(root,bg='#A6D0DD')
quizengframe = Frame(root,bg='#F7C8E0')
quizmathframe = Frame(root,bg='#C7F2A4')
courseframe = Frame(root,bg='#C7F2A4')
courseframe2 = Frame(root,bg='#C7F2A4')
courseframe3 = Frame(root,bg='#C7F2A4')
courseframe4 = Frame(root,bg='#C7F2A4')
cartframe = Frame(root,bg='#ACDCEE')
logo = PhotoImage(file="images\logo\logo1.png").subsample(1,1)
img1 = PhotoImage(file='images\logo\logo2.png').subsample(3,3)
detail = PhotoImage(file='images\detail.png').subsample(1,1)
detail2 = PhotoImage(file='images\detail2.png').subsample(1,1)
cutton = PhotoImage(file='images\cutton.png').subsample(2,2)
cutton2 = PhotoImage(file='images\cotton2.png').subsample(2,2)
qc = PhotoImage(file='images\quizz\q10.png').subsample(1,1)
qc2 = PhotoImage(file='images\quizz\q11.png').subsample(1,1)
qc3 = PhotoImage(file='images\quizz\q12.png').subsample(1,1)
l1 = PhotoImage(file='images\quizz\l1.png').subsample(3,3)
l2 = PhotoImage(file='images\quizz\l2.png').subsample(3,3)
l3 = PhotoImage(file='images\quizz\l3.png').subsample(3,3)
eng1 = PhotoImage(file='images\eng1.png').subsample(2,2)
eng2 = PhotoImage(file='images\eng2.png').subsample(2,2)
eng3 = PhotoImage(file='images\eng3.png').subsample(2,2)
eng4 = PhotoImage(file='images\eng4.png').subsample(2,2)
eng5 = PhotoImage(file='images\eng5.png').subsample(2,2)
eng6 = PhotoImage(file='images\eng6.png').subsample(2,2)
eng7 = PhotoImage(file='images\eng7.png').subsample(2,2)
eng8 = PhotoImage(file='images\eng8.png').subsample(2,2)
eng9 = PhotoImage(file='images\eng9.png').subsample(2,2)
eng10 = PhotoImage(file='images\eng10.png').subsample(2,2)
math1 = PhotoImage(file='images\math1.png').subsample(2,2)
math2 = PhotoImage(file='images\math2.png').subsample(2,2)
math3 = PhotoImage(file='images\math3.png').subsample(2,2)
math4 = PhotoImage(file='images\math4.png').subsample(2,2)
math5 = PhotoImage(file='images\math5.png').subsample(2,2)
math6 = PhotoImage(file='images\math6.png').subsample(2,2)
math7 = PhotoImage(file='images\math7.png').subsample(2,2)
math8 = PhotoImage(file='images\math8.png').subsample(2,2)
math9 = PhotoImage(file='images\math9.png').subsample(2,2)
math10 = PhotoImage(file='images\math10.png').subsample(2,2)
math11 = PhotoImage(file='images\math11.png').subsample(2,2)
com1 = PhotoImage(file='images\com1.png').subsample(2,2)
com2 = PhotoImage(file='images\com2.png').subsample(2,2)
com3 = PhotoImage(file='images\com3.png').subsample(2,2)
com4 = PhotoImage(file='images\com4.png').subsample(2,2)
com5 = PhotoImage(file='images\com5.png').subsample(2,2)
com6 = PhotoImage(file='images\com6.png').subsample(2,2)
com7 = PhotoImage(file='images\com12.png').subsample(2,2)
com8 = PhotoImage(file='images\com8.png').subsample(2,2)
com9 = PhotoImage(file='images\com9.png').subsample(2,2)
com10 = PhotoImage(file='images\com10.png').subsample(2,2)
com11 = PhotoImage(file='images\com11.png').subsample(2,2)
c1  = PhotoImage(file='images\c1.png').subsample(10,10)
c2  = PhotoImage(file='images\c2.png').subsample(10,10)
c3  = PhotoImage(file='images\c3.png').subsample(10,10)
c4  = PhotoImage(file='images\c4.png').subsample(10,10)
c5  = PhotoImage(file='images\c5.png').subsample(10,10)
thank  = PhotoImage(file='images\end.png').subsample(1,1)


mostlogo =  PhotoImage(file='images\mostlogo.png').subsample(2,2)

spy1, spy2, spy3, spy4, spy5, spy6, spy7, spy8, spy9, spy10, spy11, spy12, spy13, spy14, spy15, spy16, spy17, spy18, spy19, spy20, spy21, spy22, spy23, spy24, spy25, spy26, spy27, spy28, spy29, spy30, spy31, spy32 = IntVar(), IntVar(), IntVar(), IntVar(), IntVar(), IntVar(), IntVar(), IntVar(), IntVar(), IntVar(), IntVar(), IntVar(), IntVar(), IntVar(), IntVar(), IntVar(), IntVar(), IntVar(), IntVar(), IntVar(), IntVar(), IntVar(), IntVar(), IntVar(), IntVar(), IntVar(), IntVar(), IntVar(), IntVar(), IntVar(), IntVar(), IntVar()
total = 0

spy = IntVar()
spyt = IntVar()

loginlayout()
root.mainloop()
cursor.close()
conn.close()
